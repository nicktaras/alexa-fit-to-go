// Stores all ways of asking a user how they wish to continue.

const continueStore = [
  'To continue say next or repeat to do the step again. ',
  'To continue say either next or repeat. ',
  'To keep going, say next or repeat to try this step again. ',
  'Tell me when you\'re ready to continue, or say repeat step. '
];

module.exports = continueStore;
