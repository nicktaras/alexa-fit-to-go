const halfwayMotivationStore = [
  "You are doing great, keep going. Ok, next ",
  "Keep going, we're half way there. Ok, next, ",
  "We're half way there, nice work. So, next, "
]

module.exports = halfwayMotivationStore;
