const lastStepMotivationStore = [
  "One last time, you're doing great. ",
  "Ok, Let us do this one last time. ",
  "Let's do it one last time for luck "
]

module.exports = lastStepMotivationStore;