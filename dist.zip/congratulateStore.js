const congratulateStore = [
  'Kudos. ',
  'Nice work. ',
  'Well done. ',
  'Great job. ',
  'You did great. ',
  'You\'re a star. ',
  'Keep up the great work, well done. ',
  'You did a great job. ',
  'Very well done. ',
  'There\'s an athlete within you, great job. ',
  'Congratulations, great job. ',
  'Great job, you\'re a superstar. '
]

module.exports = congratulateStore;
