const jokeStore = [
  'I was in the gym earlier and I decided to jump on the treadmill. People were giving me weird looks, so I started jogging instead.',
  'Treadmills get you nowhere.',
  'I made the mistake of buying a running machine the other day. I Haven\'t seen it since.',
  'I have to exercise in the morning before my brain figures out what I\'m doing.',
  'Go to the gym at 4:00 in the morning and you\'ve got the whole gym to yourself.',
  'I don\'t always go to the gym, but when I do, I make sure Facebook knows about it.',
  'One does not simply get ripped in 3 weeks.'
]

module.exports = jokeStore;
