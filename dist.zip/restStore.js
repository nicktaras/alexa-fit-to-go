const restStore = [
  "and rest. ",
  "and breathe. ",
  "relax. ",
]

module.exports = restStore;