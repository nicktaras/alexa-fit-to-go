const startSpeechStore = [
  'Great ',
  'Cool ',
  'Awesome ',
  'Okay ',
]

module.exports = startSpeechStore;
