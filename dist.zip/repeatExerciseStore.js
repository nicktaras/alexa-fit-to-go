const repeatExerciseStore = [
  "and again ",
  "then. ",
]

module.exports = repeatExerciseStore;